var EXPLAIN_SHELL_ENV_INITIALIZED = "explain_shell_env_initialized";
var EXPLAIN_SHELL_ENABLE = "explain_shell_enable";
var EXPLAIN_SHELL_INJECT_TYPE = "explain_shell_inject_type";

var TRENDS_SITE_ROOT = "http://localhost:3000";

var default_settings = {};
default_settings[EXPLAIN_SHELL_ENABLE] = true;
default_settings[EXPLAIN_SHELL_INJECT_TYPE] = 0;
